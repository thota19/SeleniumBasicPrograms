package suiteclasslevelexecution;

import org.testng.annotations.Test;

public class ClassB {
	@Test
	
	public void first() {
		System.out.println("class b first"+Thread.currentThread().getId());
	}
	@Test
	public void second() {
		System.out.println("class b two"+Thread.currentThread().getId());
	}
	@Test
	public void three() {
		System.out.println("class b three"+Thread.currentThread().getId());
	}
	@Test
	public void four() {
		System.out.println("class b four"+Thread.currentThread().getId());
	}
}
