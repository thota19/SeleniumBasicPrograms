
package pavan.com.first;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class EightLocators {
	private static WebDriver driver=new ChromeDriver();
	public static void main(String[] args) throws InterruptedException {
		
		
		driver.get("https://github.com/login");
		
		highlight(driver,driver.findElement(By.id("login_field")));
		Thread.sleep(3000);
		highlight(driver,driver.findElement(By.name("password")));
		Thread.sleep(3000);
		highlight(driver,driver.findElement(By.className("header-logo")));
		
		Thread.sleep(3000);
		highlight(driver,driver.findElement(By.linkText("Forgot password?")));
		Thread.sleep(3000);
		highlight(driver,driver.findElement(By.partialLinkText("Create an ")));
		Thread.sleep(3000);
		highlight(driver,driver.findElement(By.tagName("h1")));
		Thread.sleep(3000);
		highlight(driver,driver.findElement(By.xpath("/html/body/div[1]/div[3]/main/div/div[4]/form/label")));
		Thread.sleep(3000);
		highlight(driver,driver.findElement(By.cssSelector("input[name='commit']")));
		Thread.sleep(3000);
		driver.close();
	}
	
	public static void highlight(WebDriver driver,WebElement element) {
		JavascriptExecutor je=(JavascriptExecutor)driver;
		je.executeScript("arguments[0].setAttribute('style','border:2px solid red; background:yellow;')", element);
		
	}

}
