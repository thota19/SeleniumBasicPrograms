package testingWorkingFlow;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;


public class LaunchChromeDriver {
	WebDriver driver; 
	
//	@BeforeSuite
//	public void beforeSuite() {
//		System.out.println("This is  Before Suite Method....");
//		
//	}
//	@BeforeTest
//	public void beforeTest() {
//		System.out.println("This is Before Test Method.....");
//	}
//	
	@BeforeClass
	public void beforeClass() {
		System.out.println("This is Before Class.....");
	}

	@BeforeMethod
	public void beforeMethod() {
		System.out.println("This is Before Method.....");
	    
	}
	@Test
	public void Test1() {
		System.out.println("This is Test1");
	}
	@Test
	public void Test2() {
		System.out.println("This is Test2");
	}
	
	@AfterMethod
	public void afterMethod() {
		System.out.println("This is After Method.....");
	    
	}
	

	
	
	
	
}
//@Test
//     public void findLink() {
//    	 
//    	 boolean displayed = driver.findElement(By.linkText("Gmail")).isDisplayed();
//    	 System.out.println(displayed);
//    	 
//     }
//	@AfterMethod
//	public void close()
//	{
//		driver.close();
//	}
// 	
// 	@AfterSuite
// 	public void afterSuite() {
// 		System.out.println("This is  After Suite Method....");
// 		
// 	}
// 	@AfterTest
// 	public void afterTest() {
// 		System.out.println("This is After Test Method.....");
// 	}
// 	
// 	@AfterClass
// 	public void afterClass() {
// 		System.out.println("This is After Class.....");
// 	}
//
//}
