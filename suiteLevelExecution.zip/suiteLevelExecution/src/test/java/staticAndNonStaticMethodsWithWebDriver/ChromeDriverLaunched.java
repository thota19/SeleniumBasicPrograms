package staticAndNonStaticMethodsWithWebDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class ChromeDriverLaunched {

	public static void main(String[] args) throws InterruptedException {
		
			//Initiating the chrome driver
			WebDriverManager.chromedriver().setup();		
			WebDriver driver =new ChromeDriver();
			
			//Launching the URL
			driver.get("https://www.google.com");
			Thread.sleep(1000);
			
			//Calling a Static Method
			driver = staticAndNonStaticMethods.staticClickMethod(driver);
			Thread.sleep(1000);
			
			//Calling a non - Static Method
			staticAndNonStaticMethods obj =new staticAndNonStaticMethods();
			driver = obj.nonstaticClickMethod(driver);
			Thread.sleep(1000);
			
			
			driver.close();
		
	
	}

}
