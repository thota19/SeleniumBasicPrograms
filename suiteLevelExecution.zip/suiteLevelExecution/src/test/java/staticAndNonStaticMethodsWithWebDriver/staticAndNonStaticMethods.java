package staticAndNonStaticMethodsWithWebDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class staticAndNonStaticMethods {
	
	// Static Method
	public static WebDriver staticClickMethod(WebDriver web) {
		web.findElement(By.linkText("Store")).click();
		return web;
	}
	
	// Non - Static Method
	public WebDriver nonstaticClickMethod(WebDriver web) {
		
		web.findElement(By.linkText("Support")).click();
		return web;
	}
	
}
