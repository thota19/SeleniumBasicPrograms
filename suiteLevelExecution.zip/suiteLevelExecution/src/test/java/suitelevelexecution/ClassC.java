package suitelevelexecution;

import org.testng.annotations.Test;

public class ClassC {
	@Test
	
	public void first() {
		System.out.println("class c first"+Thread.currentThread().getId());
	}
	@Test
	public void second() {
		System.out.println("class c two"+Thread.currentThread().getId());
	}
	@Test
	public void three() {
		System.out.println("class c three"+Thread.currentThread().getId());
	}
	@Test
	public void four() {
		System.out.println("class c four"+Thread.currentThread().getId());
	}
}
