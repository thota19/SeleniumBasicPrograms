package suitelevelexecution;

import org.testng.annotations.Test;

public class ClasssA {
	@Test
	
	public void first() {
		System.out.println("class a first"+Thread.currentThread().getId());
	}
	@Test
	public void second() {
		System.out.println("class a two"+Thread.currentThread().getId());
	}
	@Test
	public void three() {
		System.out.println("class a three"+Thread.currentThread().getId());
	}
	@Test
	public void four() {
		System.out.println("class a four"+Thread.currentThread().getId());
	}
}
