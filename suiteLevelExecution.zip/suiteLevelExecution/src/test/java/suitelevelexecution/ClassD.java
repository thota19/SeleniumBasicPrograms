package suitelevelexecution;

import org.testng.annotations.Test;

public class ClassD {
	@Test
	
	public void first() {
		System.out.println("class d first"+Thread.currentThread().getId());
	}
	@Test
	public void second() {
		System.out.println("class d two"+Thread.currentThread().getId());
	}
	@Test
	public void three() {
		System.out.println("class d three"+Thread.currentThread().getId());
	}
	@Test
	public void four() {
		System.out.println("class d four"+Thread.currentThread().getId());
	}
}
